import javax.swing.*;

public class swing{
    public static void main(String[] args){
       Vista f = new Vista();

        f.setSize(500,500);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
