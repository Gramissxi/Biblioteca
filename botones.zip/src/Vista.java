import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Vista  extends JFrame implements ActionListener {
    JPanel centro;
    JButton ingresar,alta,baja,con,mod,lista, silibro;
    public Vista ()
    {
        super();
        centro = new JPanel();
        JPanel panelIngresar = new JPanel();
        ingresar = new JButton("Ingresar");
        ingresar.setBackground(Color.pink);

        panelIngresar.add(ingresar);
        add(panelIngresar, BorderLayout.NORTH);
        centro.setEnabled(false);
        ingresar.addActionListener(this);
        alta = new JButton("Dar de alta");
        alta.setBackground(Color.orange);
        centro.add(alta);
        alta.setEnabled(false);
        add(centro,BorderLayout.CENTER);

        panelIngresar.add(ingresar);
        add(panelIngresar, BorderLayout.NORTH);
        centro.setEnabled(false);
        ingresar.addActionListener(this);
        baja = new JButton("Dar de baja");
        baja.setBackground(Color.orange);
        centro.add(baja);
        baja.setEnabled(false);
        add(centro,BorderLayout.CENTER);

        panelIngresar.add(ingresar);
        add(panelIngresar, BorderLayout.NORTH);
        centro.setEnabled(false);
        ingresar.addActionListener(this);
        con = new JButton("Consultar");
        con.setBackground(Color.orange);
        centro.add(con);
        con.setEnabled(false);
        add(centro,BorderLayout.CENTER);

        panelIngresar.add(ingresar);
        add(panelIngresar, BorderLayout.NORTH);
        centro.setEnabled(false);
        ingresar.addActionListener(this);
        mod = new JButton("Modificar");
        mod.setBackground(Color.orange);
        centro.add(mod);
        mod.setEnabled(false);
        add(centro,BorderLayout.CENTER);

        panelIngresar.add(ingresar);
        add(panelIngresar, BorderLayout.NORTH);
        centro.setEnabled(false);
        ingresar.addActionListener(this);
        lista = new JButton("Listado");
        lista.setBackground(Color.orange);
        centro.add(lista);
        lista.setEnabled(false);
        add(centro,BorderLayout.CENTER);

    }
    public void actionPerformed (ActionEvent e)
    {
        alta.setEnabled(true);
        baja.setEnabled(true);
        con.setEnabled(true);
        mod.setEnabled(true);
        lista.setEnabled(true);
        silibro.setEnabled(true);
    }

}
